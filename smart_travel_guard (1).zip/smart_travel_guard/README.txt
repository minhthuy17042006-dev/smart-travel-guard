SMART TRAVEL GUARD — BẢN DEMO CẬP NHẬT

Mở index.html trong trình duyệt. Để GPS hoạt động ổn định, hãy chạy trang qua HTTPS hoặc localhost và cấp quyền vị trí.

Tính năng:
- SOS: lấy GPS, tạo nội dung SOS có liên kết Google Maps, mở ứng dụng SMS để gửi cho hướng dẫn viên và số đội cứu hộ/điều hành đã lưu.
- Gọi hướng dẫn viên: gọi số đã lưu hoặc lấy GPS để soạn tin nhắn kèm vị trí.
- Báo sự cố: soạn tin có mô tả, mức độ và GPS.
- Hướng dẫn sơ cứu theo tình huống: bất tỉnh/ngừng thở, chảy máu, bỏng, gãy xương, đuối nước, say nắng, phản vệ, rắn cắn, co giật, ngạt khói/khó thở.
- Số điện thoại và tên lưu cục bộ trên trình duyệt hiện tại.

GIỚI HẠN QUAN TRỌNG:
Đây là bản frontend demo. Trình duyệt không thể tự gửi SMS âm thầm hoặc đảm bảo tin đã đến người nhận. Khi bấm gửi, ứng dụng nhắn tin sẽ mở và người dùng cần kiểm tra người nhận rồi nhấn Gửi. Muốn tự động thông báo đồng thời cho hướng dẫn viên và trung tâm cứu hộ, cần backend, dịch vụ SMS/WhatsApp phù hợp, xác thực số liên hệ, và cơ chế xác nhận đã nhận cảnh báo.
Không dùng trang này thay thế số cấp cứu chính thức. Tại Việt Nam: 113 công an, 114 cứu hỏa/cứu nạn, 115 cấp cứu y tế.
